-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.32-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for travel_agency
CREATE DATABASE IF NOT EXISTS `travel_agency` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `travel_agency`;

-- Dumping structure for table travel_agency.chitietdattour
CREATE TABLE IF NOT EXISTS `chitietdattour` (
  `maChiTietDatTour` char(7) NOT NULL,
  `maTour` char(5) NOT NULL,
  `maDatTour` char(5) NOT NULL,
  `giaVeLucBooking` bigint(20) NOT NULL,
  `soLuongVeDat` smallint(6) NOT NULL,
  `tongTien` bigint(20) NOT NULL,
  PRIMARY KEY (`maChiTietDatTour`),
  KEY `FK2_ctdt_dattour` (`maDatTour`),
  KEY `FK1_ctdt_tour` (`maTour`),
  CONSTRAINT `FK1_ctdt_tour` FOREIGN KEY (`maTour`) REFERENCES `tour` (`maTour`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK2_ctdt_dattour` FOREIGN KEY (`maDatTour`) REFERENCES `dattour` (`maDatTour`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table travel_agency.chitietdattour: ~25 rows (approximately)
INSERT INTO `chitietdattour` (`maChiTietDatTour`, `maTour`, `maDatTour`, `giaVeLucBooking`, `soLuongVeDat`, `tongTien`) VALUES
	('CTDT001', 'T001', 'DT001', 7000000, 2, 14000000),
	('CTDT002', 'T002', 'DT002', 5000000, 1, 5000000),
	('CTDT003', 'T003', 'DT003', 1200000, 4, 4800000),
	('CTDT004', 'T004', 'DT004', 8000000, 1, 8000000),
	('CTDT005', 'T005', 'DT005', 10000000, 3, 30000000),
	('CTDT006', 'T006', 'DT006', 6000000, 2, 12000000),
	('CTDT007', 'T007', 'DT007', 10000000, 1, 10000000),
	('CTDT008', 'T008', 'DT008', 8000000, 3, 24000000),
	('CTDT009', 'T009', 'DT009', 8500000, 1, 8500000),
	('CTDT010', 'T010', 'DT010', 7000000, 4, 28000000),
	('CTDT011', 'T001', 'DT011', 5500000, 3, 16500000),
	('CTDT012', 'T002', 'DT012', 4500000, 2, 9000000),
	('CTDT013', 'T003', 'DT013', 6000000, 4, 24000000),
	('CTDT014', 'T004', 'DT014', 7000000, 1, 7000000),
	('CTDT015', 'T005', 'DT015', 5000000, 5, 25000000),
	('CTDT016', 'T001', 'DT016', 5600000, 2, 11200000),
	('CTDT017', 'T002', 'DT017', 4800000, 3, 14400000),
	('CTDT018', 'T003', 'DT018', 6200000, 4, 24800000),
	('CTDT019', 'T004', 'DT019', 7400000, 1, 7400000),
	('CTDT020', 'T005', 'DT020', 5100000, 5, 25500000),
	('CTDT021', 'T001', 'DT021', 7000000, 2, 14000000),
	('CTDT022', 'T002', 'DT022', 5000000, 2, 10000000),
	('CTDT023', 'T002', 'DT023', 5000000, 2, 10000000),
	('CTDT024', 'T001', 'DT024', 7000000, 1, 7000000),
	('CTDT025', 'T005', 'DT025', 10000000, 2, 20000000);

-- Dumping structure for table travel_agency.dattour
CREATE TABLE IF NOT EXISTS `dattour` (
  `maDatTour` char(5) NOT NULL,
  `maKH` char(5) NOT NULL,
  `thoiGianDatTour` datetime NOT NULL,
  `hinhThucThanhToan` varchar(255) NOT NULL,
  `ghiChu` text DEFAULT NULL,
  `trangThaiDatTour` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`maDatTour`),
  KEY `FK1_dattour_kh` (`maKH`) USING BTREE,
  CONSTRAINT `FK1_dattour_kh` FOREIGN KEY (`maKH`) REFERENCES `khachhang` (`maKH`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table travel_agency.dattour: ~25 rows (approximately)
INSERT INTO `dattour` (`maDatTour`, `maKH`, `thoiGianDatTour`, `hinhThucThanhToan`, `ghiChu`, `trangThaiDatTour`) VALUES
	('DT001', 'KH001', '2023-10-01 09:00:00', 'Thẻ tín dụng', 'Đặt lần đầu', 'pending'),
	('DT002', 'KH002', '2023-10-02 14:00:00', 'Chuyển khoản', 'Đặt tour đi biển', 'pending'),
	('DT003', 'KH003', '2023-10-03 08:30:00', 'Tiền mặt', NULL, 'pending'),
	('DT004', 'KH004', '2023-10-05 15:00:00', 'Ví điện tử', 'Ghi chú đặc biệt', 'pending'),
	('DT005', 'KH005', '2023-10-06 11:00:00', 'Chuyển khoản', 'Đặt tour nghỉ dưỡng', 'pending'),
	('DT006', 'KH006', '2023-10-07 10:00:00', 'Thẻ tín dụng', 'Khách hàng mới', 'pending'),
	('DT007', 'KH007', '2023-10-08 15:30:00', 'Chuyển khoản', 'Đặt tour khám phá', 'pending'),
	('DT008', 'KH008', '2023-10-09 08:00:00', 'Tiền mặt', NULL, 'pending'),
	('DT009', 'KH009', '2023-10-10 14:30:00', 'Ví điện tử', 'Yêu cầu hướng dẫn viên riêng', 'pending'),
	('DT010', 'KH009', '2023-10-11 12:00:00', 'Chuyển khoản', 'Đặt tour cho gia đình', 'pending'),
	('DT011', 'KH001', '2023-10-12 09:00:00', 'Tiền mặt', 'Đặt tour cho bạn bè', 'pending'),
	('DT012', 'KH002', '2023-10-13 11:00:00', 'Chuyển khoản', 'Đặt tour cuối tuần', 'pending'),
	('DT013', 'KH003', '2023-10-14 13:00:00', 'Thẻ tín dụng', 'Tour cho cả gia đình', 'pending'),
	('DT014', 'KH004', '2023-10-15 16:30:00', 'Ví điện tử', 'Tour đặc biệt', 'pending'),
	('DT015', 'KH005', '2023-10-16 08:00:00', 'Tiền mặt', 'Tour khám phá văn hóa', 'pending'),
	('DT016', 'KH001', '2023-10-17 10:00:00', 'Tiền mặt', 'Đặt tour cho nhóm khách hàng thân thiết', 'pending'),
	('DT017', 'KH002', '2023-10-18 14:00:00', 'Chuyển khoản', 'Đặt tour gia đình dịp lễ', 'pending'),
	('DT018', 'KH003', '2023-10-19 09:30:00', 'Thẻ tín dụng', 'Tour khám phá ẩm thực', 'pending'),
	('DT019', 'KH004', '2023-10-20 13:00:00', 'Ví điện tử', 'Tour nghỉ dưỡng cuối tuần', 'pending'),
	('DT020', 'KH005', '2023-10-21 15:00:00', 'Tiền mặt', 'Tour dã ngoại cho công ty', 'pending'),
	('DT021', 'KH024', '2024-12-01 21:46:05', 'Chuyển khoản', '', 'pending'),
	('DT022', 'KH024', '2024-12-01 21:46:19', 'Thẻ tín dụng', '', 'pending'),
	('DT023', 'KH024', '2024-12-01 21:46:19', 'Thẻ tín dụng', '', 'pending'),
	('DT024', 'KH024', '2024-12-01 21:49:00', 'Tiền mặt', '', 'pending'),
	('DT025', 'KH024', '2024-12-01 21:49:16', 'Ví điện tử', '', 'pending');

-- Dumping structure for table travel_agency.khachhang
CREATE TABLE IF NOT EXISTS `khachhang` (
  `maKH` char(5) NOT NULL,
  `tenKH` varchar(255) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `gioiTinh` varchar(50) DEFAULT NULL,
  `ngaySinh` date DEFAULT NULL,
  `soDienThoai` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`maKH`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table travel_agency.khachhang: ~19 rows (approximately)
INSERT INTO `khachhang` (`maKH`, `tenKH`, `username`, `password`, `gioiTinh`, `ngaySinh`, `soDienThoai`, `email`, `status`) VALUES
	('KH001', 'Trần Đức Mạnh', 'nguyenvana', '123', 'Nam', '2024-10-05', '0866958033', 'tdmanh1510@gmail.com', 'inactive'),
	('KH002', 'Trần Thị B', 'tranthib', 'matkhau123', 'Nữ', '1985-05-15', '0909123457', 'tranthib@gmail.com', 'inactive'),
	('KH003', 'Lê Văn C', 'levanc', 'matkhau123', 'Nam', '1988-03-10', '0909123458', 'levanc@gmail.com', 'active'),
	('KH004', 'Phạm Thị D', 'phamthid', 'matkhau123', 'Nữ', '1992-07-20', '0909123459', 'phamthid@gmail.com', 'active'),
	('KH005', 'Đỗ Văn E', 'dovane', 'matkhau123', 'Nam', '1983-09-25', '0909123460', 'dovane@gmail.com', 'active'),
	('KH006', 'Bùi Văn F', 'buivanf', 'matkhau456', 'Nam', '1995-02-12', '0909123461', 'buivanf@gmail.com', 'active'),
	('KH007', 'Nguyễn Thị G', 'nguyenthig', 'matkhau456', 'Nữ', '1991-06-18', '0909123462', 'nguyenthig@gmail.com', 'active'),
	('KH008', 'Trần Văn H', 'tranvanh', 'matkhau456', 'Nam', '1987-11-09', '0909123463', 'tranvanh@gmail.com', 'active'),
	('KH009', 'Lê Thị I', 'lethii', 'matkhau456', 'Nữ', '1994-03-23', '0909123464', 'lethii@gmail.com', 'active'),
	('KH010', 'Phạm Văn K', 'phamvank', 'matkhau456', 'Nam', '1989-08-30', '0909123465', 'phamvank@gmail.com', 'active'),
	('KH011', 'Nguyễn Văn L', 'nguyenvanl', 'matkhau789', 'Nam', '1990-05-10', '0909123466', 'nguyenvanl@gmail.com', 'active'),
	('KH013', 'Lê Văn N', 'levann', 'matkhau789', 'Nam', '1985-07-08', '0909123468', 'levann@gmail.com', 'active'),
	('KH014', 'Phạm Thị O', 'phamthio', 'matkhau123', 'Nữ', '1998-11-20', '0909123469', 'phamthio@gmail.com', 'inactive'),
	('KH015', 'Đỗ Văn P', 'dovanp', 'matkhau123', 'Nam', '1993-02-25', '0909123470', 'dovanp@gmail.com', 'active'),
	('KH016', 'Bùi Văn Q', 'buivanq', 'matkhau123', 'Nam', '1996-04-12', '0909123471', 'buivanq@gmail.com', 'active'),
	('KH019', 'Lê Thị T', 'lethit', 'matkhau456', 'Nữ', '1989-12-30', '0909123474', 'lethit@gmail.com', 'active'),
	('KH021', 'Nguyễn Văn V', 'nguyenvanv', 'matkhau123', 'Nam', '1994-03-18', '0909123476', 'nguyenvanv@gmail.com', 'inactive'),
	('KH023', 'Lê Văn X', 'levanx', 'matkhau123', 'Nam', '1990-09-14', '0909123478', 'levanx@gmail.com', 'active'),
	('KH024', 'minh binhf', 'minhleo', '123', 'Nam', '2024-11-15', '1234', 'minhleo@123', 'active');

-- Dumping structure for table travel_agency.loaitour
CREATE TABLE IF NOT EXISTS `loaitour` (
  `maLoaiTour` char(5) NOT NULL,
  `tenLoaiTour` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`maLoaiTour`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table travel_agency.loaitour: ~5 rows (approximately)
INSERT INTO `loaitour` (`maLoaiTour`, `tenLoaiTour`) VALUES
	('LT001', 'Tour biển'),
	('LT002', 'Tour leo núi'),
	('LT003', 'Tour du lịch sinh thái'),
	('LT004', 'Tour lịch sử - văn hóa'),
	('LT005', 'Tour nghỉ dưỡng');

-- Dumping structure for table travel_agency.nhanvien
CREATE TABLE IF NOT EXISTS `nhanvien` (
  `maNV` char(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`maNV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table travel_agency.nhanvien: ~5 rows (approximately)
INSERT INTO `nhanvien` (`maNV`, `username`, `password`) VALUES
	('NV001', 'john', 'pass1'),
	('NV002', 'jane', 'pass2'),
	('NV003', 'mike', 'pass3'),
	('NV004', 'emily', 'pass4'),
	('NV005', 'chris', 'pass5');

-- Dumping structure for table travel_agency.tour
CREATE TABLE IF NOT EXISTS `tour` (
  `maTour` char(4) NOT NULL,
  `maLoaiTour` char(5) NOT NULL,
  `tenTour` text NOT NULL,
  `diemXuatPhat` text NOT NULL,
  `diemKetThuc` text NOT NULL,
  `phuongTienDiChuyen` text NOT NULL,
  `thoiGianXuatPhat` datetime NOT NULL,
  `thoiGianKetThuc` datetime NOT NULL,
  `soLuongVeToiDa` smallint(6) NOT NULL DEFAULT 0,
  `soLuongVeHienCo` smallint(6) NOT NULL DEFAULT 0,
  `giaVeHienTai` bigint(20) NOT NULL DEFAULT 0,
  `giaVeLucTruoc` bigint(20) NOT NULL DEFAULT 0,
  `moTa` text DEFAULT NULL,
  `fileName` text DEFAULT NULL,
  PRIMARY KEY (`maTour`),
  UNIQUE KEY `fileName` (`fileName`) USING HASH,
  UNIQUE KEY `tenTour` (`tenTour`) USING HASH,
  KEY `FK1_tour_loaitour` (`maLoaiTour`),
  CONSTRAINT `FK1_tour_loaitour` FOREIGN KEY (`maLoaiTour`) REFERENCES `loaitour` (`maLoaiTour`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table travel_agency.tour: ~69 rows (approximately)
INSERT INTO `tour` (`maTour`, `maLoaiTour`, `tenTour`, `diemXuatPhat`, `diemKetThuc`, `phuongTienDiChuyen`, `thoiGianXuatPhat`, `thoiGianKetThuc`, `soLuongVeToiDa`, `soLuongVeHienCo`, `giaVeHienTai`, `giaVeLucTruoc`, `moTa`, `fileName`) VALUES
	('T001', 'LT001', 'Tour Đà Nẵng', 'Hà Nội', 'Đà Nẵng', 'Máy bay', '2023-12-01 08:00:00', '2023-12-07 18:00:00', 20, 10, 7000000, 6500000, 'Khám phá Đà Nẵng xinh đẹp', NULL),
	('T002', 'LT002', 'Tour Sapa', 'Hà Nội', 'Sapa', 'Xe khách', '2023-12-05 06:00:00', '2023-12-10 20:00:00', 15, 5, 5000000, 4500000, 'Tham quan vùng núi Sapa', NULL),
	('T003', 'LT003', 'Tour Cần Giờ', 'TP.HCM', 'Cần Giờ', 'Ô tô', '2023-11-20 07:00:00', '2023-11-21 17:00:00', 25, 13, 1200000, 1100000, 'Du lịch sinh thái tại Cần Giờ', NULL),
	('T004', 'LT004', 'Tour Huế', 'Hà Nội', 'Huế', 'Máy bay', '2023-12-15 09:00:00', '2023-12-20 19:00:00', 18, 15, 8000000, 7500000, 'Khám phá cố đô Huế', NULL),
	('T005', 'LT005', 'Tour Phú Quốc', 'Hà Nội', 'Phú Quốc', 'Máy bay', '2023-12-25 10:00:00', '2024-01-01 20:00:00', 22, 7, 10000000, 9500000, 'Nghỉ dưỡng tại đảo Phú Quốc', NULL),
	('T006', 'LT004', 'Tour Fansipan', 'Hà Nội', 'Sapa', 'Xe khách', '2024-01-10 05:00:00', '2024-01-15 20:00:00', 20, 18, 6000000, 5500000, 'Chinh phục đỉnh Fansipan', NULL),
	('T007', 'LT002', 'Tour Hang Sơn Đoòng', 'Huế', 'Quảng Bình', 'Ô tô', '2024-02-01 07:00:00', '2024-02-05 18:00:00', 12, 11, 10000000, 9500000, 'Khám phá hang động lớn nhất thế giới', NULL),
	('T008', 'LT005', 'Tour Ẩm Thực Huế', 'TP.HCM', 'Huế', 'Máy bay', '2024-02-10 09:00:00', '2024-02-15 19:00:00', 25, 22, 8000000, 7500000, 'Thưởng thức ẩm thực cung đình Huế', NULL),
	('T009', 'LT003', 'Tour Lịch Sử Cố Đô', 'Hà Nội', 'Huế', 'Máy bay', '2024-03-05 08:00:00', '2024-03-10 18:00:00', 20, 19, 8500000, 8000000, 'Khám phá các di tích lịch sử cố đô Huế', NULL),
	('T010', 'LT001', 'Tour Gia Đình Đà Lạt', 'TP.HCM', 'Đà Lạt', 'Xe khách', '2024-04-01 06:00:00', '2024-04-06 20:00:00', 30, 26, 7000000, 6500000, 'Kỳ nghỉ gia đình tại Đà Lạt', NULL),
	('T011', 'LT002', 'Tour Núi Bà Đen', 'Hồ Chí Minh', 'Tây Ninh', 'Xe máy', '2024-01-05 06:00:00', '2024-01-05 20:00:00', 20, 20, 200000, 180000, 'Tham quan đỉnh núi Bà Đen', NULL),
	('T012', 'LT004', 'Tour Cố Đô Huế', 'Hà Nội', 'Huế', 'Tàu hỏa', '2024-02-15 07:00:00', '2024-02-20 19:00:00', 15, 15, 6000000, 5500000, 'Khám phá lịch sử cố đô Huế', NULL),
	('T013', 'LT001', 'Tour Đảo Bình Ba', 'Hồ Chí Minh', 'Khánh Hòa', 'Máy bay', '2024-03-10 08:00:00', '2024-03-14 18:00:00', 10, 10, 8000000, 7500000, 'Thưởng ngoạn cảnh đẹp biển Bình Ba', NULL),
	('T014', 'LT003', 'Tour Cần Giờ 2', 'Hồ Chí Minh', 'Cần Giờ', 'Ô tô', '2024-03-25 07:00:00', '2024-03-26 17:00:00', 25, 25, 1000000, 900000, 'Du lịch sinh thái rừng ngập mặn Cần Giờ', NULL),
	('T015', 'LT005', 'Tour Phú Quốc 2', 'Hà Nội', 'Phú Quốc', 'Máy bay', '2024-04-01 10:00:00', '2024-04-07 20:00:00', 20, 20, 10000000, 9500000, 'Kỳ nghỉ dưỡng tại Phú Quốc', NULL),
	('T016', 'LT003', 'Tour Hồ Ba Bể', 'Hà Nội', 'Bắc Kạn', 'Ô tô', '2024-04-15 06:00:00', '2024-04-18 18:00:00', 30, 30, 5000000, 4500000, 'Khám phá vẻ đẹp hồ Ba Bể', NULL),
	('T017', 'LT001', 'Tour Nha Trang', 'Hồ Chí Minh', 'Nha Trang', 'Máy bay', '2024-05-05 08:00:00', '2024-05-10 18:00:00', 25, 25, 9000000, 8500000, 'Tham quan các bãi biển đẹp tại Nha Trang', NULL),
	('T018', 'LT004', 'Tour Địa Đạo Củ Chi', 'Hồ Chí Minh', 'Củ Chi', 'Xe máy', '2024-05-20 07:00:00', '2024-05-20 19:00:00', 15, 15, 200000, 180000, 'Tìm hiểu lịch sử tại địa đạo Củ Chi', NULL),
	('T019', 'LT005', 'Tour Đà Lạt', 'Hồ Chí Minh', 'Đà Lạt', 'Ô tô', '2024-06-01 06:00:00', '2024-06-05 20:00:00', 30, 30, 7000000, 6500000, 'Nghỉ dưỡng tại thành phố hoa Đà Lạt', NULL),
	('T020', 'LT002', 'Tour Fansipan 2', 'Hà Nội', 'Sapa', 'Tàu hỏa', '2024-06-15 05:00:00', '2024-06-20 20:00:00', 10, 10, 6000000, 5500000, 'Chinh phục đỉnh Fansipan', NULL),
	('T021', 'LT003', 'Tour Tràm Chim', 'Hồ Chí Minh', 'Đồng Tháp', 'Ô tô', '2024-07-05 06:00:00', '2024-07-07 17:00:00', 25, 25, 1500000, 1400000, 'Tham quan vườn quốc gia Tràm Chim', NULL),
	('T022', 'LT004', 'Tour Điện Biên', 'Hà Nội', 'Điện Biên', 'Máy bay', '2024-07-20 08:00:00', '2024-07-25 18:00:00', 15, 15, 7000000, 6500000, 'Khám phá lịch sử chiến thắng Điện Biên Phủ', NULL),
	('T023', 'LT005', 'Tour Bà Nà Hills', 'Đà Nẵng', 'Bà Nà', 'Cáp treo', '2024-08-01 09:00:00', '2024-08-01 18:00:00', 20, 20, 1000000, 900000, 'Tham quan khu du lịch Bà Nà Hills', NULL),
	('T024', 'LT002', 'Tour Hạ Long', 'Hà Nội', 'Quảng Ninh', 'Tàu thuyền', '2024-08-15 07:00:00', '2024-08-18 19:00:00', 30, 30, 8000000, 7500000, 'Tham quan vịnh Hạ Long kỳ quan thế giới', NULL),
	('T025', 'LT001', 'Tour Côn Đảo', 'Hồ Chí Minh', 'Côn Đảo', 'Máy bay', '2024-09-01 10:00:00', '2024-09-05 20:00:00', 10, 10, 12000000, 11500000, 'Khám phá thiên nhiên hoang sơ tại Côn Đảo', NULL),
	('T026', 'LT003', 'Tour Hồ Tràm', 'Hồ Chí Minh', 'Vũng Tàu', 'Ô tô', '2024-09-20 07:00:00', '2024-09-22 18:00:00', 25, 25, 2000000, 1900000, 'Du lịch biển Hồ Tràm', NULL),
	('T027', 'LT004', 'Tour Mỹ Sơn', 'Đà Nẵng', 'Quảng Nam', 'Xe máy', '2024-10-05 06:00:00', '2024-10-05 18:00:00', 15, 15, 500000, 450000, 'Tìm hiểu di sản văn hóa Mỹ Sơn', NULL),
	('T028', 'LT002', 'Tour Sapa 2', 'Hà Nội', 'Sapa', 'Xe khách', '2024-10-15 05:00:00', '2024-10-20 20:00:00', 20, 20, 5000000, 4500000, 'Tham quan núi rừng Sapa', NULL),
	('T029', 'LT005', 'Tour Ninh Thuận', 'Hồ Chí Minh', 'Ninh Thuận', 'Ô tô', '2024-11-01 06:00:00', '2024-11-05 20:00:00', 30, 30, 7000000, 6500000, 'Nghỉ dưỡng tại bãi biển Ninh Thuận', NULL),
	('T030', 'LT001', 'Tour Biển Hồ Cốc', 'Hồ Chí Minh', 'Hồ Cốc', 'Ô tô', '2024-11-10 06:00:00', '2024-11-12 18:00:00', 30, 30, 3000000, 2800000, 'Tham quan bãi biển yên bình Hồ Cốc', NULL),
	('T031', 'LT002', 'Tour Trekking Hà Giang', 'Hà Nội', 'Hà Giang', 'Ô tô', '2024-11-15 06:00:00', '2024-11-20 20:00:00', 20, 20, 7000000, 6500000, 'Trải nghiệm trekking tại Hà Giang', NULL),
	('T032', 'LT003', 'Tour Vườn Quốc Gia Cúc Phương', 'Hà Nội', 'Ninh Bình', 'Ô tô', '2024-11-25 06:00:00', '2024-11-27 18:00:00', 25, 25, 1500000, 1400000, 'Khám phá thiên nhiên tại vườn quốc gia', NULL),
	('T033', 'LT004', 'Tour Thành Cổ Quảng Trị', 'Đà Nẵng', 'Quảng Trị', 'Xe máy', '2024-12-01 07:00:00', '2024-12-02 19:00:00', 15, 15, 2000000, 1800000, 'Tìm hiểu di tích lịch sử Quảng Trị', NULL),
	('T034', 'LT005', 'Tour Resort Hồ Tràm', 'Hồ Chí Minh', 'Hồ Tràm', 'Ô tô', '2024-12-05 06:00:00', '2024-12-08 20:00:00', 30, 30, 6000000, 5500000, 'Kỳ nghỉ dưỡng tại khu resort Hồ Tràm', NULL),
	('T035', 'LT001', 'Tour Biển Cà Ná', 'Hồ Chí Minh', 'Cà Ná', 'Ô tô', '2024-12-15 07:00:00', '2024-12-17 20:00:00', 25, 25, 4000000, 3700000, 'Khám phá vẻ đẹp hoang sơ của biển Cà Ná', NULL),
	('T036', 'LT002', 'Tour Trekking Bạch Mã', 'Đà Nẵng', 'Huế', 'Ô tô', '2024-12-20 06:00:00', '2024-12-22 18:00:00', 20, 20, 5000000, 4500000, 'Chinh phục đỉnh Bạch Mã', NULL),
	('T037', 'LT003', 'Tour Rừng Nam Cát Tiên', 'Hồ Chí Minh', 'Đồng Nai', 'Ô tô', '2024-12-25 06:00:00', '2024-12-28 18:00:00', 30, 30, 2000000, 1900000, 'Trải nghiệm du lịch sinh thái rừng Nam Cát Tiên', NULL),
	('T038', 'LT004', 'Tour Cố Đô Hoa Lư', 'Hà Nội', 'Ninh Bình', 'Ô tô', '2024-12-30 06:00:00', '2025-01-01 18:00:00', 20, 20, 3000000, 2800000, 'Tìm hiểu lịch sử tại cố đô Hoa Lư', NULL),
	('T039', 'LT005', 'Tour Resort Đảo Cô Tô', 'Hà Nội', 'Quảng Ninh', 'Tàu thuyền', '2025-01-05 08:00:00', '2025-01-10 20:00:00', 15, 15, 8000000, 3200000, 'Nghỉ dưỡng tại đảo Cô Tô', NULL),
	('T040', 'LT001', 'Tour Biển Mũi Né', 'Hồ Chí Minh', 'Phan Thiết', 'Ô tô', '2025-01-15 06:00:00', '2025-01-18 18:00:00', 30, 30, 4500000, 5400000, 'Khám phá bãi biển Mũi Né', NULL),
	('T041', 'LT002', 'Tour Trekking Tây Côn Lĩnh', 'Hà Nội', 'Hà Giang', 'Ô tô', '2025-01-20 06:00:00', '2025-01-25 20:00:00', 20, 20, 9000000, 7800000, 'Trải nghiệm leo núi Tây Côn Lĩnh', NULL),
	('T042', 'LT003', 'Tour Động Phong Nha', 'Huế', 'Quảng Bình', 'Ô tô', '2025-02-01 07:00:00', '2025-02-03 18:00:00', 25, 25, 6000000, 1300000, 'Khám phá vẻ đẹp của động Phong Nha', NULL),
	('T043', 'LT004', 'Tour Kinh Thành Huế', 'Đà Nẵng', 'Huế', 'Ô tô', '2025-02-10 06:00:00', '2025-02-12 19:00:00', 20, 20, 4000000, 990000, 'Tìm hiểu lịch sử kinh thành Huế', NULL),
	('T044', 'LT005', 'Tour Resort Cam Ranh', 'Hồ Chí Minh', 'Khánh Hòa', 'Máy bay', '2025-02-15 08:00:00', '2025-02-20 20:00:00', 30, 30, 10000000, 4200000, 'Nghỉ dưỡng tại bãi biển Cam Ranh', NULL),
	('T045', 'LT001', 'Tour Biển Đồ Sơn', 'Hà Nội', 'Hải Phòng', 'Ô tô', '2025-02-25 06:00:00', '2025-02-27 18:00:00', 25, 25, 3500000, 6300000, 'Khám phá bãi biển Đồ Sơn', NULL),
	('T046', 'LT002', 'Tour Trekking Fansipan 3', 'Hà Nội', 'Sapa', 'Tàu hỏa', '2025-03-01 05:00:00', '2025-03-05 20:00:00', 10, 10, 6000000, 2500000, 'Leo núi Fansipan lần 3', NULL),
	('T047', 'LT003', 'Tour Rừng Phú Quốc', 'Hồ Chí Minh', 'Phú Quốc', 'Máy bay', '2025-03-10 06:00:00', '2025-03-15 18:00:00', 20, 20, 7000000, 5700000, 'Khám phá rừng sinh thái tại Phú Quốc', NULL),
	('T048', 'LT004', 'Tour Thành Nhà Hồ', 'Hà Nội', 'Thanh Hóa', 'Ô tô', '2025-03-20 06:00:00', '2025-03-22 19:00:00', 20, 20, 2500000, 6900000, 'Tham quan di sản lịch sử Thành Nhà Hồ', NULL),
	('T049', 'LT005', 'Tour Resort Phú Yên', 'Hồ Chí Minh', 'Phú Yên', 'Máy bay', '2025-03-25 08:00:00', '2025-03-30 20:00:00', 25, 25, 8500000, 880000, 'Nghỉ dưỡng tại bãi biển Phú Yên', NULL),
	('T050', 'LT001', 'Tour Biển Ninh Chữ', 'Hồ Chí Minh', 'Ninh Thuận', 'Ô tô', '2025-04-05 06:00:00', '2025-04-07 18:00:00', 30, 30, 4000000, 3300000, 'Tham quan bãi biển Ninh Chữ', NULL),
	('T051', 'LT002', 'Tour Trekking Pù Luông', 'Hà Nội', 'Thanh Hóa', 'Ô tô', '2025-04-10 06:00:00', '2025-04-13 18:00:00', 20, 20, 4500000, 4700000, 'Khám phá thiên nhiên tại Pù Luông', NULL),
	('T052', 'LT003', 'Tour Rừng U Minh Hạ', 'Cần Thơ', 'Cà Mau', 'Ô tô', '2025-04-15 07:00:00', '2025-04-17 18:00:00', 25, 25, 3000000, 6100000, 'Tham quan rừng U Minh Hạ', NULL),
	('T053', 'LT004', 'Tour Chùa Bái Đính', 'Hà Nội', 'Ninh Bình', 'Ô tô', '2025-04-20 06:00:00', '2025-04-21 18:00:00', 30, 30, 2500000, 5300000, 'Tham quan quần thể chùa Bái Đính', NULL),
	('T054', 'LT005', 'Tour Resort Vũng Tàu', 'Hồ Chí Minh', 'Vũng Tàu', 'Ô tô', '2025-04-25 06:00:00', '2025-04-27 18:00:00', 35, 35, 5000000, 3600000, 'Nghỉ dưỡng tại resort ven biển Vũng Tàu', NULL),
	('T055', 'LT001', 'Tour Biển Bình Ba', 'Nha Trang', 'Khánh Hòa', 'Tàu thuyền', '2025-05-01 07:00:00', '2025-05-04 20:00:00', 25, 25, 6000000, 2800000, 'Tham quan đảo Bình Ba', NULL),
	('T056', 'LT002', 'Tour Trekking Tà Đùng', 'Đà Lạt', 'Đắk Nông', 'Ô tô', '2025-05-10 06:00:00', '2025-05-13 18:00:00', 15, 15, 5000000, 0, 'Khám phá vẻ đẹp hoang sơ tại Tà Đùng', NULL),
	('T057', 'LT003', 'Tour Rừng Yok Đôn', 'Buôn Ma Thuột', 'Đắk Lắk', 'Ô tô', '2025-05-15 06:00:00', '2025-05-18 18:00:00', 20, 20, 4000000, 0, 'Trải nghiệm thiên nhiên hoang dã tại Yok Đôn', NULL),
	('T058', 'LT004', 'Tour Đền Hùng', 'Hà Nội', 'Phú Thọ', 'Ô tô', '2025-05-20 07:00:00', '2025-05-21 18:00:00', 40, 40, 2000000, 0, 'Hành hương về đền Hùng', NULL),
	('T059', 'LT005', 'Tour Resort Côn Đảo', 'Hồ Chí Minh', 'Côn Đảo', 'Máy bay', '2025-05-25 08:00:00', '2025-05-30 20:00:00', 15, 15, 12000000, 0, 'Nghỉ dưỡng tại Côn Đảo', NULL),
	('T060', 'LT001', 'Tour Biển Mỹ Khê', 'Đà Nẵng', 'Quảng Ngãi', 'Ô tô', '2025-06-01 06:00:00', '2025-06-03 18:00:00', 30, 30, 3500000, 0, 'Tham quan bãi biển Mỹ Khê', NULL),
	('T061', 'LT002', 'Tour Trekking Bidoup', 'Đà Lạt', 'Lâm Đồng', 'Ô tô', '2025-06-05 06:00:00', '2025-06-08 18:00:00', 15, 15, 5500000, 0, 'Khám phá núi rừng Bidoup', NULL),
	('T062', 'LT003', 'Tour Thác Bản Giốc', 'Hà Nội', 'Cao Bằng', 'Ô tô', '2025-06-10 06:00:00', '2025-06-13 18:00:00', 20, 20, 7000000, 0, 'Khám phá thiên nhiên tại thác Bản Giốc', NULL),
	('T063', 'LT004', 'Tour Phố Cổ Hội An', 'Đà Nẵng', 'Hội An', 'Xe máy', '2025-06-15 07:00:00', '2025-06-16 19:00:00', 25, 25, 2000000, 0, 'Trải nghiệm phố cổ Hội An', NULL),
	('T064', 'LT005', 'Tour Resort Nha Trang', 'Hồ Chí Minh', 'Khánh Hòa', 'Máy bay', '2025-06-20 08:00:00', '2025-06-25 20:00:00', 40, 40, 9000000, 0, 'Nghỉ dưỡng tại thành phố biển Nha Trang', NULL),
	('T065', 'LT001', 'Tour Biển An Bàng', 'Hội An', 'Quảng Nam', 'Ô tô', '2025-06-28 06:00:00', '2025-06-30 18:00:00', 20, 20, 3000000, 0, 'Thư giãn tại bãi biển An Bàng', NULL),
	('T066', 'LT002', 'Tour Trekking Lảo Thẩn', 'Hà Nội', 'Lào Cai', 'Ô tô', '2025-07-05 06:00:00', '2025-07-10 20:00:00', 15, 15, 8000000, 0, 'Leo núi Lảo Thẩn - nóc nhà Y Tý', NULL),
	('T067', 'LT003', 'Tour Hồ Ba Bể 2', 'Hà Nội', 'Bắc Kạn', 'Ô tô', '2025-07-15 06:00:00', '2025-07-18 18:00:00', 25, 25, 5000000, 0, 'Khám phá vẻ đẹp hoang sơ tại Hồ Ba Bể', NULL),
	('T068', 'LT004', 'Tour Văn Miếu Quốc Tử Giám', 'Hà Nội', 'Hà Nội', 'Xe đạp', '2025-07-20 08:00:00', '2025-07-20 12:00:00', 50, 50, 1000000, 0, 'Tham quan Văn Miếu - Quốc Tử Giám', NULL),
	('T069', 'LT005', 'Tour Resort Quy Nhơn', 'Hồ Chí Minh', 'Bình Định', 'Máy bay', '2025-07-25 08:00:00', '2025-07-30 20:00:00', 35, 35, 8500000, 0, 'Nghỉ dưỡng tại thành phố biển Quy Nhơn', NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
